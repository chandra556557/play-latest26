@echo off
echo Starting AI Analysis Service...
echo.

REM Activate virtual environment if it exists
if exist venv\Scripts\activate.bat (
    call venv\Scripts\activate.bat
) else (
    echo Warning: Virtual environment not found
    echo Please run setup.bat first
    pause
    exit /b 1
)

REM Start the FastAPI server
echo.
echo Starting FastAPI server on http://localhost:8000
echo Press Ctrl+C to stop
echo.

python main.py
